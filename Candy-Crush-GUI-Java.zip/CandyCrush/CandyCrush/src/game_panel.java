import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.util.List;

/**
 * @author AliMirash
 */
public class game_panel extends JFrame {

    Random rand = new Random();
    private int score = 0;
    private JLabel score_lb;
    private final JToggleButton [] buttons = new JToggleButton[100];
    private JButton save;
    private JButton exit;

    private final Icon blue = new ImageIcon(String.valueOf(new ImageIcon("imageicon/blue.png")));
    private final Icon red = new ImageIcon(String.valueOf(new ImageIcon("imageicon/red.png")));
    private final Icon green = new ImageIcon(String.valueOf(new ImageIcon("imageicon/green.png")));
    private final Icon yellow = new ImageIcon(String.valueOf(new ImageIcon("imageicon/yellow.png")));
    private final Icon blueLR = new ImageIcon(String.valueOf(new ImageIcon("imageicon/blueLR.png")));
    private final Icon redLR = new ImageIcon(String.valueOf(new ImageIcon("imageicon/redLR.png")));
    private final Icon greenLR = new ImageIcon(String.valueOf(new ImageIcon("imageicon/greenLR.png")));
    private final Icon yellowLR = new ImageIcon(String.valueOf(new ImageIcon("imageicon/yellowLR.png")));
    private final Icon blueLC = new ImageIcon(String.valueOf(new ImageIcon("imageicon/blueLC.png")));
    private final Icon redLC = new ImageIcon(String.valueOf(new ImageIcon("imageicon/redLC.png")));
    private final Icon greenLC = new ImageIcon(String.valueOf(new ImageIcon("imageicon/greenLC.png")));
    private final Icon yellowLC = new ImageIcon(String.valueOf(new ImageIcon("imageicon/yellowLC.png")));
    private final Icon blueRC = new ImageIcon(String.valueOf(new ImageIcon("imageicon/blueRC.png")));
    private final Icon redRC = new ImageIcon(String.valueOf(new ImageIcon("imageicon/redRC.png")));
    private final Icon greenRC = new ImageIcon(String.valueOf(new ImageIcon("imageicon/greenRC.png")));
    private final Icon yellowRC = new ImageIcon(String.valueOf(new ImageIcon("imageicon/yellowRC.png")));
    private final Icon menu_Icon = new ImageIcon(String.valueOf(new ImageIcon("button/Menu.png")));
    private final Icon save_Icon = new ImageIcon(String.valueOf(new ImageIcon("button/Save.png")));
    private final ArrayList<Icon> LR_candies = new ArrayList<>(List.of(blueLR,yellowLR,greenLR,redLR));
    private final ArrayList<Icon> LC_candies = new ArrayList<>(List.of(blueLC,yellowLC,greenLC,redLC));
    private final ArrayList<Icon> RC_candies = new ArrayList<>(List.of(blueRC,yellowRC,greenRC,redRC));

    private final ArrayList<Integer> rowCh = new ArrayList<>();
    private final ArrayList<Integer> colChj = new ArrayList<>();
    private final Map<Integer,ArrayList<Integer>> colCh = new HashMap<>();
    private final ArrayList<Integer> selec_int = new ArrayList<>();



    public void create_Candy_new() {
        for (int i = 0; i < 100; i++) {
            randIcon(i);
        }
        remove_candyBC();
        playGame();

    }

    private void remove_candyBC() {
        while (checkRow_3() ) {
            firstDelRow();
            invalidate();
            validate();
            repaint();
        }
        while (checkCol_3() ) {
            firstDelCol();
            invalidate();
            validate();
            repaint();
        }
    }// remove Candies Before Click (after Set Random Candies)

    private void remove_candyAC() {
        if (checkRow_5()) {
            checkPanelRow_5();
            invalidate();validate();repaint();
        }
        if (checkCol_5()) {
            checkPanelCol_5();
            invalidate();validate();repaint();
        }
        if (checkRow_4()) {
            checkPanelRow_4();
            invalidate();validate();repaint();
        }
        if (checkCol_4()) {
            checkPanelCol_4();
            invalidate();validate();repaint();
        }
        if (checkRow_3()) {
            checkPanelRow_3();
            invalidate();validate();repaint();
        }
        if (checkCol_3()) {
            checkPanelCol_3();
            invalidate();validate();repaint();
        }
    }// remove same Candies After Select two Candies

    public void create_Candy_withFile(File file){
        try {
            Scanner scan = new Scanner(file);
            score = scan.nextInt();
            score_lb.setText(String.valueOf(score));
            String sfile = "";
            while (scan.hasNextLine()){
                sfile += scan.nextLine();
                sfile += ",";
            }
            String[] res = sfile.split(",");

            for (int i = 1; i < 101; i++) {
                switch (res[i]){
                    case "SCR":
                        buttons[i-1].setIcon(red);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "SCG":
                        buttons[i-1].setIcon(green);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "SCB":
                        buttons[i-1].setIcon(blue);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "SCY":
                        buttons[i-1].setIcon(yellow);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "LRR":
                        buttons[i-1].setIcon(redLR);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "LRG":
                        buttons[i-1].setIcon(greenLR);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "LRB":
                        buttons[i-1].setIcon(blueLR);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "LRY":
                        buttons[i-1].setIcon(yellowLR);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "LCR":
                        buttons[i-1].setIcon(redLC);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "LCG":
                        buttons[i-1].setIcon(greenLC);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "LCB":
                        buttons[i-1].setIcon(blueLC);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "LCY":
                        buttons[i-1].setIcon(yellowLC);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "RCR":
                        buttons[i-1].setIcon(redRC);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "RCG":
                        buttons[i-1].setIcon(greenRC);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "RCB":
                        buttons[i-1].setIcon(blueRC);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                    case "RCY":
                        buttons[i-1].setIcon(yellowRC);
                        buttons[i-1].setOpaque(false);
                        buttons[i-1].setBorderPainted(false);
                        buttons[i-1].setContentAreaFilled(false);
                        break;
                }
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        remove_candyBC();
        playGame();
    }

    public void playGame() {
        ActionListener itemListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JToggleButton btn = (JToggleButton) e.getSource();

                if (btn.isSelected()) {
                    if (select_two_candy()) {
                        selec_int.clear();
                        int s1, s2;
                        for (int i = 0; i < 100; i++) {
                            if (buttons[i].isSelected()) {
                                selec_int.add(i);
                            }
                        }
                        s1 = selec_int.get(0);
                        s2 = selec_int.get(1);
                        if (checkSelected(s1, s2)) {
                            changeIcon(s1, s2);
                            if (score >= 1500) {
                                save_score();
                                dispose();
                                youWin youWin = new youWin();
                                youWin.setVisible(true);

                            }
                            if (LR_candies.contains(buttons[s1].getIcon())) {
                                check_LR_button(s1, s2);
                                remove_candyBC();
                            }
                            if (LR_candies.contains(buttons[s2].getIcon())) {
                                check_LR_button(s2, s1);
                                remove_candyBC();
                            }
                            if (LC_candies.contains(buttons[s1].getIcon())) {
                                check_LC_button(s1, s2);
                                remove_candyBC();
                            }
                            if (LC_candies.contains(buttons[s2].getIcon())) {
                                check_LC_button(s2, s1);
                                remove_candyBC();
                            }
                            if (RC_candies.contains(buttons[s1].getIcon())) {
                                check_RC_button(s1, s2);
                                remove_candyBC();
                            }
                            if (RC_candies.contains(buttons[s2].getIcon())) {
                                check_RC_button(s2, s1);
                                remove_candyBC();
                            }
                            else {
                                remove_candyAC();
                                remove_candyBC();
                            }

                            for (int i = 0; i < 100; i++) {
                                buttons[i].setSelected(false);
                            }
                        } else {
                            for (int i = 0; i < 100; i++) {
                                buttons[i].setSelected(false);
                            }
                        }
                    }
                }
            }
        };

        for (int i = 0; i < 100; i++) {
            buttons[i].addActionListener(itemListener);
        }
    }// check Select two Candy and check Score

    private boolean select_two_candy(){
        int count = 0;
        for (int i = 0; i < 100; i++) {
            if(buttons[i].isSelected()){
                count++;
            }
        }
        return (count == 2);
    }

    private void check_LR_button(int s1, int s2) {
        if (buttons[s1].getIcon() == blueLR && buttons[s2].getIcon() == blue) {
            remove_LR(s1);
        }
        if (buttons[s1].getIcon() == redLR && buttons[s2].getIcon() == red) {
            remove_LR(s1);
        }
        if (buttons[s1].getIcon() == greenLR && buttons[s2].getIcon() == green) {
            remove_LR(s1);
        }
        if (buttons[s1].getIcon() == yellowLR && buttons[s2].getIcon() == yellow) {
            remove_LR(s1);
        }
    }

    private void check_LC_button(int s1, int s2) {
        if (buttons[s1].getIcon() == blueLC && buttons[s2].getIcon() == blue) {
            remove_LC(s1);
        }
        if (buttons[s1].getIcon() == redLC && buttons[s2].getIcon() == red) {
            remove_LC(s1);
        }
        if (buttons[s1].getIcon() == greenLC && buttons[s2].getIcon() == green) {
            remove_LC(s1);
        }
        if (buttons[s1].getIcon() == yellowLC && buttons[s2].getIcon() == yellow) {
            remove_LC(s1);
        }
    }

    private void check_RC_button(int s1, int s2){
        if (buttons[s1].getIcon() == blueRC && buttons[s2].getIcon() == blue) {
            remove_RC(s1);
        }
        if (buttons[s1].getIcon() == redRC && buttons[s2].getIcon() == red) {
            remove_RC(s1);
        }
        if (buttons[s1].getIcon() == greenRC && buttons[s2].getIcon() == green) {
            remove_RC(s1);
        }
        if (buttons[s1].getIcon() == yellowRC && buttons[s2].getIcon() == yellow) {
            remove_RC(s1);
        }
    }

    private void remove_LR(int s1) {
        int temp = s1 % 10;
        for (int i = 0; i <= 9; i++) {
             randIcon(temp * 10 + i);
        }
        score += 10;
        score_lb.setText(String.valueOf(score));
    }

    private void remove_LC(int s1){
        int temp = s1 % 10;
        int num_col = (s1 - (temp * 10));
        for (int i = 0; i < 9; i++) {
            randIcon((i * 10) + num_col);
        }
        score += 10;
        score_lb.setText(String.valueOf(score));

    }

    private void remove_RC(int s1){
        int temp = s1 % 10;
        int num_col = (s1 - (temp * 10));
        for (int i = temp -2; i <= temp + 2 ; i++) {
            if (num_col >= 2 && num_col <= 7) {
                for (int j = num_col - 2; j <= num_col + 2; j++) {
                    randIcon((i * 10) + j);
                }
            }
            if (num_col == 1 || num_col == 0) {
                for (int j = 0; j <= num_col + 2; j++) {
                    randIcon((i * 10) + j);
                }
            }
            if (num_col == 8 || num_col == 9) {
                for (int j = num_col - 2; j <= 9; j++) {
                    randIcon((i * 10) + j);
                }
            }
        }
        score += 15;
        score_lb.setText(String.valueOf(score));
    }

    private boolean checkSelected(int s1 , int s2){
        if ((s1 == s2 + 1) && (s2 % 10 <= 8)) {
            return true;
        }
        if ((s2 == s1 + 1) && (s1 % 10 <= 8)) {
            return true;
        }
        if ((s1 == s2 - 1) && (s2 % 10 >= 1)) {
            return true;
        }
        if ((s2 == s1 - 1) && (s1 % 10 >= 1)) {
            return true;
        }
        if ((s1 == s2 + 10)) {
            return true;
        }
        if ((s2 == s1 + 10)) {
            return true;
        }
        if ((s1 == s2 - 10)) {
            return true;
        }
        return s2 == s1 - 10;
    }

    private void firstDelRow(){
        for (Integer ch : rowCh) {
            Icon c = buttons[ch].getIcon();
            Icon c1 = buttons[ch + 1].getIcon();
            Icon c2 = buttons[ch + 2].getIcon();

            if (c == c1 && c == c2) {
                randIcon(ch);
                randIcon(ch + 1);
                randIcon(ch + 2);
                score += 5;
                score_lb.setText(String.valueOf(score));
            }
        }
    }

    private void firstDelCol(){
        for (int i = 0; i < 9; i++) {
            if (colCh.containsKey(i)) {
                ArrayList<Integer> colArr = new ArrayList<>(colCh.get(i));
                for (int col : colArr) {
                    Icon c1 = buttons[(col * 10) + i].getIcon();
                    Icon c2 = buttons[((col + 1) * 10) + i].getIcon();
                    Icon c3 = buttons[((col + 2) * 10) + i].getIcon();

                    if (c1 == c2 && c1 == c3) {
                        randIcon((col * 10) + i);
                        randIcon(((col + 1) * 10) + i);
                        randIcon(((col + 2) * 10) + i);
                        score += 5;
                        score_lb.setText(String.valueOf(score));
                    }
                }
            }
        }
    }

    private boolean checkRow_3() {
        int bol=0;
        rowCh.clear();
        for (int i = 0; i < 98 ; i++) {
            if (i % 10 <= 7) {
                Icon cj = buttons[i].getIcon();
                Icon cj1 = buttons[i + 1].getIcon();
                Icon cj2 = buttons[i + 2].getIcon();


                if (cj == cj1 && cj == cj2) {
                    rowCh.add(i);
                    bol++;
                }
            }
        }
        return bol != 0;
    }

    private boolean checkCol_3(){
        int bol = 0;
        int numi = 0;
        for (int i = 0; i <= 9; i++) {
            for (int j = 0; j < 8; j++) {
                Icon cj = buttons[(10 * j) + i].getIcon();
                Icon cj1 = buttons[(10 * j) + 10 + i].getIcon();
                Icon cj2 = buttons[(10 * j) + 20 + i].getIcon();

                if (cj == cj1 && cj == cj2) {
                    numi = 1;
                    colChj.add(j);
                    bol++;
                }
            }
            if (numi == 1) {
                ArrayList<Integer> temp = new ArrayList<>(colChj);
                colCh.put(i,temp);
                colChj.clear();
                numi = 0;
            }
        }
        return bol != 0;
    }

    private boolean checkRow_4(){
        int bol=0;
        rowCh.clear();
        for (int i = 0; i < 97 ; i++) {
            if (i % 10 < 7) {
                Icon cj = buttons[i].getIcon();
                Icon cj1 = buttons[i + 1].getIcon();
                Icon cj2 = buttons[i + 2].getIcon();
                Icon cj3 = buttons[i + 3].getIcon();


                if (cj == cj1 && cj == cj2 && cj==cj3) {
                    rowCh.add(i);
                    bol++;
                }
            }
        }
        return bol != 0;
    }

    private boolean checkCol_4(){
        int bol = 0;
        int numi = 0;
        colCh.clear();
        colChj.clear();
        for (int i = 0; i <= 9; i++) {
            for (int j = 0; j <= 6; j++) {
                Icon cj = buttons[(10 * j) + i].getIcon();
                Icon cj1 = buttons[(10 * j) + 10 + i].getIcon();
                Icon cj2 = buttons[(10 * j) + 20 + i].getIcon();
                Icon cj3 = buttons[(10 * j) + 30 + i].getIcon();


                if (cj == cj1 && cj == cj2 && cj==cj3) {
                    numi = 1;
                    colChj.add(j);
                    bol++;
                }
            }
            if (numi == 1) {
                ArrayList<Integer> temp = new ArrayList<>(colChj);
                colCh.put(i,temp);
                colChj.clear();
                numi = 0;
            }
        }
        return bol != 0;
    }

    private boolean checkRow_5(){
        int bol=0;
        rowCh.clear();
        for (int i = 0; i < 96 ; i++) {
            if (i % 10 < 6) {
                Icon cj = buttons[i].getIcon();
                Icon cj1 = buttons[i + 1].getIcon();
                Icon cj2 = buttons[i + 2].getIcon();
                Icon cj3 = buttons[i + 3].getIcon();
                Icon cj4 = buttons[i + 4].getIcon();


                if (cj == cj1 && cj == cj2 && cj==cj3 && cj == cj4) {
                    rowCh.add(i);
                    bol++;
                }
            }
        }
        return bol != 0;
    }

    private boolean checkCol_5(){
        int bol = 0;
        int numi = 0;
        colCh.clear();
        colChj.clear();
        for (int i = 0; i <= 9; i++) {
            for (int j = 0; j <= 5; j++) {
                Icon cj = buttons[(10 * j) + i].getIcon();
                Icon cj1 = buttons[(10 * j) + 10 + i].getIcon();
                Icon cj2 = buttons[(10 * j) + 20 + i].getIcon();
                Icon cj3 = buttons[(10 * j) + 30 + i].getIcon();
                Icon cj4 = buttons[(10 * j) + 40 + i].getIcon();


                if (cj == cj1 && cj == cj2 && cj==cj3 && cj == cj4) {
                    numi = 1;
                    colChj.add(j);
                    bol++;
                }
            }
            if (numi == 1) {
                ArrayList<Integer> temp = new ArrayList<>(colChj);
                colCh.put(i,temp);
                colChj.clear();
                numi = 0;
            }
        }
        return bol != 0;
    }

    private void checkPanelRow_3(){
        for (Integer ch : rowCh) {
            Icon c = buttons[ch].getIcon();
            Icon c1 = buttons[ch + 1].getIcon();
            Icon c2 = buttons[ch + 2].getIcon();


            if (c == c1 && c == c2) {
                int numj = ch;
                for (int k = 0; k < (ch / 10) - 1; k++) {
                    changeIcon(numj, numj - 10);
                    changeIcon(numj + 1, numj - 9);
                    changeIcon(numj + 2, numj - 8);
                    numj -= 10;
                    score += 5;
                    score_lb.setText(String.valueOf(score));
                }
                randIcon(ch % 10 );
                randIcon(ch % 10 + 1);
                randIcon(ch % 10 + 2);
            }
        }
    }

    private void checkPanelCol_3() {

        for (int i = 0; i < 10; i++) {
            if (colCh.containsKey(i)) {
                ArrayList<Integer> colArr = new ArrayList<>(colCh.get(i));
                for (int col:colArr) {
                    Icon c1 = buttons[(col * 10) + i].getIcon();
                    Icon c2 = buttons[((col + 1) * 10) + i].getIcon();
                    Icon c3 = buttons[((col + 2) * 10) + i].getIcon();

                    if (c1 == c2 && c1 == c3)  {
                        for (int j = col; j > 0 ; j--) {
                            changeIcon((col * 10) + i,((col - 1) * 10) + i);
                            changeIcon(((col + 1) * 10) + i,(col * 10) + i);
                            changeIcon(((col + 2) * 10) + i,((col + 1) * 10) + i);
                            score += 5;
                            score_lb.setText(String.valueOf(score));
                        }
                        randIcon(i);
                        randIcon(i + 1);
                        randIcon(i + 2);
                    }
                }
            }
        }
    }

    private void checkPanelRow_4(){
        for (Integer ch : rowCh) {
            Icon c = buttons[ch].getIcon();
            Icon c1 = buttons[ch + 1].getIcon();
            Icon c2 = buttons[ch + 2].getIcon();
            Icon c3 = buttons[ch + 3].getIcon();

            if (c == c1 && c == c2 && c == c3) {
                int numj = ch;
                if (yellow.equals(c)) {
                    buttons[numj].setIcon(yellowLR);
                } else if (blue.equals(c)) {
                    buttons[numj].setIcon(blueLR);
                } else if (red.equals(c)) {
                    buttons[numj].setIcon(redLR);
                } else if (green.equals(c)) {
                    buttons[numj].setIcon(greenLR);
                }
                for (int k = 0; k < (ch / 10) - 1; k++) {
                    changeIcon(numj + 1, numj - 9);
                    changeIcon(numj + 2, numj - 8);
                    changeIcon(numj + 3, numj - 7);
                    numj -= 10;
                    score += 7;
                    score_lb.setText(String.valueOf(score));
                }
                randIcon(ch % 10 + 1);
                randIcon(ch % 10 + 2);
                randIcon(ch % 10 + 3);
            }
        }
    }

    private void checkPanelCol_4(){

        for (int i = 0; i < 10; i++) {
            if (colCh.containsKey(i)) {
                ArrayList<Integer> colArr = new ArrayList<>(colCh.get(i));
                for (int col:colArr) {
                    Icon c1 = buttons[(col * 10) + i].getIcon();
                    Icon c2 = buttons[((col + 1) * 10) + i].getIcon();
                    Icon c3 = buttons[((col + 2) * 10) + i].getIcon();
                    Icon c4 = buttons[((col + 3) * 10) + i].getIcon();

                    if (yellow.equals(c4)) {
                        buttons[((col + 3) * 10) + i].setIcon(yellowLC);
                    } else if (blue.equals(c4)) {
                        buttons[((col + 3) * 10) + i].setIcon(blueLC);
                    } else if (red.equals(c4)) {
                        buttons[((col + 3) * 10) + i].setIcon(redLC);
                    } else if (green.equals(c4)) {
                        buttons[((col + 3) * 10) + i].setIcon(greenLC);
                    }


                    if (c1 == c2 && c1 == c3 && c1 == c4) {
                        for (int j = col; j > 0 ; j--) {
                            changeIcon((col * 10) + i,((col - 1) * 10) + i);
                            changeIcon(((col + 1) * 10) + i,(col * 10) + i);
                            changeIcon(((col + 2) * 10) + i,((col + 1) * 10) + i);
                            score += 7;
                            score_lb.setText(String.valueOf(score));
                        }
                        randIcon(i);
                        randIcon(i + 1);
                        randIcon(i + 2);
                    }
                }
            }
        }
    }

    private void checkPanelRow_5(){
        for (Integer ch : rowCh) {
            Icon c = buttons[ch].getIcon();
            Icon c1 = buttons[ch + 1].getIcon();
            Icon c2 = buttons[ch + 2].getIcon();
            Icon c3 = buttons[ch + 3].getIcon();
            Icon c4 = buttons[ch + 4].getIcon();

            if (c == c1 && c == c2 && c == c3 && c == c4){
                int numj = ch;
                if (yellow.equals(c)) {
                    buttons[numj].setIcon(yellowRC);
                } else if (blue.equals(c)) {
                    buttons[numj].setIcon(blueRC);
                } else if (red.equals(c)) {
                    buttons[numj].setIcon(redRC);
                } else if (green.equals(c)) {
                    buttons[numj].setIcon(greenRC);
                }
                for (int k = 0; k < (ch / 10) - 1; k++) {
                    changeIcon(numj + 1, numj - 9);
                    changeIcon(numj + 2, numj - 8);
                    changeIcon(numj + 3, numj - 7);
                    changeIcon(numj + 4, numj - 6);
                    numj -= 10;
                    score += 9;
                    score_lb.setText(String.valueOf(score));
                }
                randIcon(ch % 10 + 1);
                randIcon(ch % 10 + 2);
                randIcon(ch % 10 + 3);
                randIcon(ch % 10 + 4);
            }
        }
    }

    private void checkPanelCol_5(){
        for (int i = 0; i < 10; i++) {
            if (colCh.containsKey(i)) {
                ArrayList<Integer> colArr = new ArrayList<>(colCh.get(i));
                for (int col:colArr) {
                    Icon c1 = buttons[(col * 10) + i].getIcon();
                    Icon c2 = buttons[((col + 1) * 10) + i].getIcon();
                    Icon c3 = buttons[((col + 2) * 10) + i].getIcon();
                    Icon c4 = buttons[((col + 3) * 10) + i].getIcon();
                    Icon c5 = buttons[((col + 4) * 10) + i].getIcon();

                    if (yellow.equals(c5)) {
                        buttons[((col + 4) * 10) + i].setIcon(yellowRC);
                    } else if (blue.equals(c5)) {
                        buttons[((col + 4) * 10) + i].setIcon(blueRC);
                    } else if (red.equals(c5)) {
                        buttons[((col + 4) * 10) + i].setIcon(redRC);
                    } else if (green.equals(c5)) {
                        buttons[((col + 4) * 10) + i].setIcon(greenRC);
                    }

                    if (c1 == c2 && c1 == c3 && c1 == c4 && c1 == c5) {
                        for (int j = col; j > 0 ; j--) {
                            changeIcon((col * 10) + i,((col - 1) * 10) + i);
                            changeIcon(((col + 1) * 10) + i,(col * 10) + i);
                            changeIcon(((col + 2) * 10) + i,((col + 1) * 10) + i);
                            changeIcon(((col + 3) * 10) + i,((col + 2) * 10) + i);
                            score += 9;
                            score_lb.setText(String.valueOf(score));
                        }
                        randIcon(i);
                        randIcon(i + 1);
                        randIcon(i + 2);
                        randIcon(i + 3);
                    }
                }
            }
        }
    }

    private void changeIcon(int a1 , int a2){
        Icon temp = buttons[a1].getIcon();
        buttons[a1].setIcon(buttons[a2].getIcon());
        buttons[a2].setIcon(temp);
    }

    private void randIcon(int i) {
        int x = rand.nextInt(400) + 1;
        switch (x % 4) {
            case 0 -> {
                buttons[i].setIcon(blue);
                buttons[i].setOpaque(false);
                buttons[i].setBorderPainted(false);
                buttons[i].setContentAreaFilled(false);
            }
            case 1 -> {
                buttons[i].setIcon(red);
                buttons[i].setOpaque(false);
                buttons[i].setBorderPainted(false);
                buttons[i].setContentAreaFilled(false);
            }
            case 2 -> {
                buttons[i].setIcon(green);
                buttons[i].setOpaque(false);
                buttons[i].setBorderPainted(false);
                buttons[i].setContentAreaFilled(false);
            }
            case 3 -> {
                buttons[i].setIcon(yellow);
                buttons[i].setOpaque(false);
                buttons[i].setBorderPainted(false);
                buttons[i].setContentAreaFilled(false);
            }
        }
    }

    public game_panel() {
            initComponents();
        }

    public void save_score() {
            try {
                FileWriter wr = new FileWriter("score.cvs", true);
                wr.write(score_lb.getText() + "\n");
                wr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    private void initComponents() {

            JPanel jPanel1 = new JPanel();
            JLabel jLabel1 = new JLabel();
            score_lb = new JLabel();
            JLabel jLabel3 = new JLabel();
            exit = new JButton();
            save = new JButton();


        jPanel1.setOpaque(false);
        try {
            final Image backgroundImage = javax.imageio.ImageIO.read(new File("gamePB.jpg"));
            setContentPane(new JPanel(new BorderLayout()) {
                @Override public void paintComponent(Graphics g) {
                    g.drawImage(backgroundImage, 0, 0, null);
                }
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
            setTitle("Candy Crush");
            setResizable(false);

            jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
            jPanel1.setPreferredSize(new java.awt.Dimension(600, 600));
            jPanel1.setLayout(new java.awt.GridLayout(10, 10, 1, 1));


            for (int i = 0; i < 100; i++) {
                buttons[i] = new JToggleButton();
                jPanel1.add(buttons[i]);
            }


            jLabel1.setBackground(new java.awt.Color(255, 255, 0));
            jLabel1.setFont(new java.awt.Font("Adobe Devanagari", 3, 25)); // NOI18N
            jLabel1.setForeground(new java.awt.Color(153, 0, 51));
            jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            jLabel1.setText("Score:");

            score_lb.setFont(new java.awt.Font("Bookman Old Style", 3, 25)); // NOI18N
            score_lb.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            score_lb.setText("0");

            exit.setBackground(new java.awt.Color(255, 51, 0));
            exit.setBorderPainted(false);
            exit.setContentAreaFilled(false);
            exit.setOpaque(false);
            exit.setIcon(menu_Icon);
            exit.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    exitActionPerformed(evt);
                }
            });

            jLabel3.setFont(new java.awt.Font("ESSTIXFifteen", Font.BOLD | Font.ITALIC, 30)); // NOI18N
            jLabel3.setForeground(new java.awt.Color(130, 65, 210));
            jLabel3.setText("Candy Crush");

            save.setBorderPainted(false);
            save.setContentAreaFilled(false);
            save.setOpaque(false);
            save.setIcon(save_Icon);
            save.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    saveActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                    layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                    .addContainerGap()
                                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(score_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(exit))
                                            .addGroup(layout.createSequentialGroup()
                                                    .addGap(25, 25, 25)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addGroup(layout.createSequentialGroup()
                                                                    .addComponent(save)
                                                                    .addGap(111, 111, 111)
                                                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGap(0, 15, Short.MAX_VALUE)))
                                    .addContainerGap())
            );
            layout.setVerticalGroup(
                    layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(save))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(score_lb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(exit)))
            );

            jPanel1.getAccessibleContext().setAccessibleName("");

            pack();
            setLocationRelativeTo(null);
        }

    private void saveActionPerformed(ActionEvent evt) {
            try {
                FileWriter writer = new FileWriter("resume.cvs");
                writer.append(String.valueOf(score));
                writer.append("\n");
                for (int i = 0; i < 10; i++) {
                    for (int j = 0; j < 10; j++) {
                        Icon c = buttons[i * 10 + j].getIcon();
                        if (c == blue) {
                            writer.append("SCB");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == red) {
                            writer.append("SCR");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == green) {
                            writer.append("SCG");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == yellow) {
                            writer.append("SCY");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == blueLR) {
                            writer.append("LRB");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == redLR) {
                            writer.append("LRR");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == greenLR) {
                            writer.append("LRG");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == yellowLR) {
                            writer.append("LRY");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == blueLC) {
                            writer.append("LCB");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == redLC) {
                            writer.append("LCR");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == greenLC) {
                            writer.append("LCG");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == yellowLC) {
                            writer.append("LCY");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == blueRC) {
                            writer.append("RCB");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == redRC) {
                            writer.append("RCR");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == greenRC) {
                            writer.append("RCG");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }
                        if (c == yellowRC) {
                            writer.append("RCY");
                            if (j != 9) {
                                writer.append(",");
                            }
                        }

                    }
                    writer.append("\n");
                }
                writer.close();
                save_score();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {
            dispose();
            new Menu().setVisible(true);
        }

    public static void main(String[] args) {
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                java.util.logging.Logger.getLogger(game_panel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }

            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    new game_panel().setVisible(true);
                }
            });
        }

}