import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;

/**
 * @author AliMirash
 */
public class Menu extends JFrame {
    private JFrame frame;
    private JButton exit;
    private JButton highScore;
    private JButton newGame;
    private JButton resume;
    private JButton startWithFile;
    private final Icon resume_Icon = new ImageIcon(String.valueOf(new ImageIcon("button/Resume.png")));
    private final Icon highSCore_Icon = new ImageIcon(String.valueOf(new ImageIcon("button/HighScore.png")));
    private final Icon newGame_Icon = new ImageIcon(String.valueOf(new ImageIcon("button/NewGame.png")));
    private final Icon exit_Icon = new ImageIcon(String.valueOf(new ImageIcon("button/Exit.png")));
    private final Icon startWithFile_Icon = new ImageIcon(String.valueOf(new ImageIcon("button/StartWithFile.png")));


    public Menu() {
        initComponents();
    }

    private void initComponents() {
        newGame = new javax.swing.JButton();
        resume = new javax.swing.JButton();
        highScore = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        startWithFile = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Candy Crush");
        setBackground(new java.awt.Color(204, 255, 255));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setIconImages(null);
        setName("Candy Crush"); // NOI18N
        setResizable(false);

        try {
            final Image backgroundImage = javax.imageio.ImageIO.read(new File("menuBack.jpg"));
            setContentPane(new JPanel(new BorderLayout()) {
                @Override public void paintComponent(Graphics g) {
                    g.drawImage(backgroundImage, 0, 0, null);
                }
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        newGame.setBorderPainted(false);
        newGame.setContentAreaFilled(false);
        newGame.setOpaque(false);
        newGame.setIcon(newGame_Icon);
        newGame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newGameActionPerformed(evt);
            }
        });


        resume.setBorderPainted(false);
        resume.setContentAreaFilled(false);
        resume.setOpaque(false);
        resume.setIcon(resume_Icon);

        resume.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resumeActionPerformed(evt);
            }
        });

        highScore.setBorderPainted(false);
        highScore.setContentAreaFilled(false);
        highScore.setOpaque(false);
        highScore.setIcon(highSCore_Icon);
        highScore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                highScoreActionPerformed(evt);
            }
        });

        exit.setBorderPainted(false);
        exit.setContentAreaFilled(false);
        exit.setOpaque(false);
        exit.setIcon(exit_Icon);
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });

        startWithFile.setBorderPainted(false);
        startWithFile.setContentAreaFilled(false);
        startWithFile.setOpaque(false);
        startWithFile.setIcon(startWithFile_Icon);
        startWithFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startWithFileActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(highScore)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 338, Short.MAX_VALUE)
                                .addComponent(exit, GroupLayout.DEFAULT_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(resume, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(newGame, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(startWithFile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap(172, Short.MAX_VALUE)
                                .addComponent(resume, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(newGame, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(startWithFile, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(exit, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(highScore, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap())
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
        setLocationRelativeTo(null);
    }

    private void startWithFileActionPerformed(ActionEvent evt) {
        JFileChooser fc = new JFileChooser();
        File file = null;
        FileNameExtensionFilter filter = new FileNameExtensionFilter("CVS File","cvs");
        fc.setFileFilter(filter);
        int returnVal = fc.showOpenDialog(null);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            file = fc.getSelectedFile();
        }
        dispose();
        game_panel game = new game_panel();
        game.setVisible(true);
        game.create_Candy_withFile(file);
    }

    private void highScoreActionPerformed(ActionEvent evt) {
        dispose();
        high_score high = new high_score();
        high.setVisible(true);
    }// high score

    private void resumeActionPerformed(ActionEvent evt) {
        dispose();
        game_panel game = new game_panel();
        game.setVisible(true);
        game.create_Candy_withFile(new File("resume.cvs"));
    }// resume

    private void newGameActionPerformed(ActionEvent evt) {
        dispose();
        game_panel game = new game_panel();
        game.setVisible(true);
        game.create_Candy_new();

    }// new game

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {
        frame = new JFrame("Exit");
        if(JOptionPane.showConfirmDialog(frame ,"Confirm if you want to exit.","Candy Crush",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){
            System.exit(0);
        }     }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }
    
}