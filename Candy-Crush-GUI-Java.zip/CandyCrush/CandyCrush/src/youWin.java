import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;

/**
 * @author AliMirash
 */
public class youWin extends javax.swing.JFrame {

    private final JButton continueGame = new JButton();
    private final JButton restart = new JButton();
    private final Icon continue_Icon = new ImageIcon(String.valueOf(new ImageIcon("button/continue.png")));
    private final Icon restart_Icon = new ImageIcon(String.valueOf(new ImageIcon("button/restart.png")));


    public youWin() {
        initComponents();
    }

    private void initComponents() {


        try {
            final Image backgroundImage = javax.imageio.ImageIO.read(new File("YouWin.jpg"));

            setContentPane(new JPanel(new BorderLayout()) {
                @Override public void paintComponent(Graphics g) {
                    g.drawImage(backgroundImage, 0, 0, null);
                }
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        continueGame.setIcon(continue_Icon);
        continueGame.setBorderPainted(false);
        continueGame.setContentAreaFilled(false);
        continueGame.setOpaque(false);
        continueGame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                continueGameActionPerformed(evt);
            }
        });
        restart.setIcon(restart_Icon);
        restart.setBorderPainted(false);
        restart.setContentAreaFilled(false);
        restart.setOpaque(false);
        restart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restartActionPerformed(evt);
            }
        });

        setSize(650,375);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 0, 255));
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(90, 90, 90)
                                .addComponent(restart, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 100, Short.MAX_VALUE)
                                .addComponent(continueGame, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(270, 270, 270)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(restart, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                                        .addComponent(continueGame, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(67, 67, 67))
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void continueGameActionPerformed(ActionEvent evt) {
        dispose();
        Menu menu = new Menu();
        menu.setVisible(true);
    }

    private void restartActionPerformed(ActionEvent evt) {
        dispose();
        game_panel game = new game_panel();
        game.setVisible(true);
        game.create_Candy_new();

    }

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(youWin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new youWin().setVisible(true);
            }
        });
    }
}
